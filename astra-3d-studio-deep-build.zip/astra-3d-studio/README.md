# ASTRA 3D STUDIO — base independente para um agente de criação 3D

Este repositório é uma base de desenvolvimento, **não um modelo de IA próprio e não um produto oficial da OpenAI, Anthropic ou de qualquer outro fornecedor**. O objetivo é construir por etapas uma plataforma de criação de sites 3D assistida por IA.

## O que existe nesta versão

- Interface React + TypeScript + Vite, adaptada a telas pequenas.
- Prévia WebGL usando Three.js / React Three Fiber e geometria procedural de demonstração.
- Editor de arquivos do workspace, persistência local, histórico de cena e exportação ZIP.
- Backend Node/Express com integração opcional a API compatível com OpenAI Chat Completions.
- Endpoint `/api/agent/run`: agente iterativo que pode listar, ler e escrever arquivos dentro de um workspace em memória, com limite de etapas, validação de caminhos, limite de tamanho e validação das ações. O modelo escolhe uma ação por etapa e recebe o resultado para decidir a próxima.
- Endpoint `/api/ai/edit`: alteração estruturada da especificação da cena.

## Requisitos

- Node.js 20 ou mais recente
- npm 10+

## Executar localmente

```bash
npm install
cp .env.example server/.env
npm run dev
```

Abra `http://localhost:5173`. A API fica em `http://localhost:8787`.

## Conectar o modelo de IA

Configure `server/.env` com um provedor e modelo aos quais você tenha acesso:

```env
PORT=8787
CLIENT_ORIGIN=http://localhost:5173
AI_BASE_URL=https://api.openai.com/v1
AI_API_KEY=sua_chave_apenas_no_servidor
AI_MODEL=nome-real-do-modelo-disponível-na-sua-conta
```

O endpoint usa `/chat/completions`. A chave deve permanecer apenas no servidor; nunca a coloque no frontend nem publique o `.env`. Modelos, limites e custos dependem do provedor escolhido. Sem credenciais, a interface funciona apenas no modo local e o Deep Build não consegue chamar um modelo.

## Usar o Deep Build

1. Inicie o backend e configure as variáveis de ambiente.
2. Abra a aplicação e descreva uma tarefa concreta no painel ASTRA.
3. Pressione **Deep Build · editar arquivos com IA**.
4. O agente recebe o workspace atual e pode realizar várias operações de leitura/escrita até oito etapas.
5. Revise as mudanças antes de usá-las ou publicá-las.

### Limites honestos desta versão

- O agente ainda **não executa comandos de terminal, builds, testes de navegador ou código arbitrário**. Ele informa isso na conclusão em vez de fingir que os testes passaram.
- O workspace do agente é mantido na requisição e devolvido ao navegador; ainda não existe armazenamento versionado no servidor.
- Não há ainda sandbox de execução de projetos gerados, publicação automática, autenticação de usuários, quotas por conta ou rate limit de produção. Não exponha publicamente o backend antes de adicionar esses controles.
- A importação GLB/glTF valida extensão e tamanho, mas o upload ainda não está conectado ao carregador visual do viewport.
- A exportação atual é um pacote de workspace de demonstração, não garante um site independente pronto para publicar.
- A cena é procedural e não substitui modelos 3D profissionais licenciados.
- Não é possível afirmar que o sistema supera GPT-6, Claude ou Claude Code sem uma infraestrutura/modelo próprios e avaliações reproduzíveis contra esses sistemas.

## Testes e build

```bash
npm test
npm run build
```

Os testes devem ser executados em ambiente com dependências instaladas. Não considere o projeto validado até os comandos concluírem com sucesso.

## Segurança

O agente não executa shell nem código gerado. Há validação de caminho e limites de arquivos/tamanho, mas esta é uma base de desenvolvimento, não uma implementação de produção endurecida. Antes de disponibilizar na internet, adicione autenticação, rate limiting, limites de custo, logs sem segredos, revisão de CORS e um sandbox/container isolado para qualquer execução futura de código.
