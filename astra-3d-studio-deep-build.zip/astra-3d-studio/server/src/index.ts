import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import { z } from 'zod';

const app=express();
const port=Number(process.env.PORT||8787);
app.disable('x-powered-by');
app.use(helmet({crossOriginResourcePolicy:{policy:'cross-origin'}}));
app.use(cors({origin: process.env.CLIENT_ORIGIN || 'http://localhost:5173'}));
app.use(express.json({limit:'128kb'}));
const requestSchema=z.object({prompt:z.string().trim().min(1).max(4000),currentSpec:z.record(z.unknown()).optional()});
const specSchema=z.object({title:z.string().max(80).optional(),subtitle:z.string().max(180).optional(),accent:z.string().regex(/^#[0-9a-fA-F]{6}$/).optional(),object:z.enum(['car','orb','shoe']).optional(),motion:z.number().min(0).max(2).optional(),glow:z.number().min(0).max(2).optional()});
app.get('/api/health',(_req,res)=>res.json({ok:true,service:'astra-3d-studio-api',aiConfigured:Boolean(process.env.AI_API_KEY&&process.env.AI_BASE_URL&&process.env.AI_MODEL),model:process.env.AI_MODEL||null}));
app.post('/api/ai/edit',async(req,res)=>{
 const parsed=requestSchema.safeParse(req.body); if(!parsed.success)return res.status(400).json({error:'Pedido inválido ou muito grande.'});
 const {prompt,currentSpec={}}=parsed.data;
 if(!process.env.AI_API_KEY||!process.env.AI_BASE_URL||!process.env.AI_MODEL)return res.status(503).json({error:'Nenhum provedor de IA configurado. Defina AI_BASE_URL, AI_API_KEY e AI_MODEL no .env do backend.'});
 try {
  const response=await fetch(`${process.env.AI_BASE_URL!.replace(/\/$/,'')}/chat/completions`,{method:'POST',headers:{'Authorization':`Bearer ${process.env.AI_API_KEY}`,'Content-Type':'application/json'},body:JSON.stringify({model:process.env.AI_MODEL,temperature:0.2,max_tokens:700,messages:[{role:'system',content:'Você edita uma especificação JSON de cena 3D. Retorne somente JSON válido com campos opcionais title, subtitle, accent (#RRGGBB), object (car|orb|shoe), motion (0-2), glow (0-2). Preserve campos não afetados. Nunca retorne código executável.'},{role:'user',content:`Cena atual: ${JSON.stringify(currentSpec)}\nPedido: ${prompt}`} ]}),signal:AbortSignal.timeout(25000)});
  if(!response.ok){const body=(await response.text()).slice(0,500);return res.status(response.status===429?429:502).json({error:`Provedor recusou a solicitação (HTTP ${response.status}).`,detail:body});}
  const data=await response.json() as {choices?:{message?:{content?:string}}[]}; const content=data.choices?.[0]?.message?.content||'';
  const clean=content.replace(/^```(?:json)?\s*/i,'').replace(/\s*```$/,'').trim(); let json:unknown;
  try{json=JSON.parse(clean);}catch{return res.status(502).json({error:'O provedor não retornou JSON válido.'});}
  const valid=specSchema.safeParse(json); if(!valid.success)return res.status(502).json({error:'A resposta da IA não passou na validação de esquema.'});
  return res.json({spec:valid.data,provider:'configured'});
 } catch(error){const message=error instanceof Error?error.message:'Erro desconhecido';return res.status(502).json({error:`Falha ao conectar ao provedor: ${message}`});}
});

const agentRequestSchema=z.object({
 prompt:z.string().trim().min(1).max(6000),
 files:z.record(z.string().max(80000)).default({}),
 maxSteps:z.number().int().min(1).max(8).optional()
});
const safePath=(name:string)=>{
 if(!name || name.length>160 || name.startsWith('/') || name.includes('\\') || name.split('/').some(part=>!part || part==='.' || part==='..') || !/^[a-zA-Z0-9._/-]+$/.test(name)) return false;
 return !/(^|\/)(\.env|secrets?)(\.|$)/i.test(name) && !name.endsWith('.pem') && !name.endsWith('.key');
};
const agentActionSchema=z.discriminatedUnion('action',[
 z.object({action:z.literal('list_files')}),
 z.object({action:z.literal('read_file'),path:z.string().min(1).max(160)}),
 z.object({action:z.literal('write_file'),path:z.string().min(1).max(160),content:z.string().max(80000),reason:z.string().max(300).optional()}),
 z.object({action:z.literal('finish'),summary:z.string().max(1200),checks:z.array(z.string().max(240)).max(12).default([])})
]);
app.post('/api/agent/run',async(req,res)=>{
 const parsed=agentRequestSchema.safeParse(req.body);
 if(!parsed.success) return res.status(400).json({error:'Pedido inválido: limite de 6.000 caracteres no prompt e 80 KB por arquivo.'});
 if(!process.env.AI_API_KEY||!process.env.AI_BASE_URL||!process.env.AI_MODEL) return res.status(503).json({error:'Agente indisponível: configure AI_BASE_URL, AI_API_KEY e AI_MODEL no backend.'});
 const {prompt,files:inputFiles}=parsed.data;
 const files:Record<string,string>={}; let total=0;
 for(const [name,content] of Object.entries(inputFiles)) {
  if(!safePath(name)) return res.status(400).json({error:`Caminho de arquivo não permitido: ${name}`});
  total+=name.length+content.length; if(Object.keys(files).length>=40||total>300000) return res.status(413).json({error:'Workspace acima do limite do agente (40 arquivos / 300 KB).'});
  files[name]=content;
 }
 const steps:string[]=[]; let summary='O agente atingiu o limite de etapas antes de finalizar.'; let checks:string[]=[];
 const system=`Você é o agente de engenharia ASTRA Deep Build. Trabalhe como programador experiente. O usuário quer: ${prompt}\n\nWorkspace inicial (nomes e conteúdo): ${JSON.stringify(files)}\n\nVocê deve agir UMA etapa por vez e responder SOMENTE com um objeto JSON válido. Formatos: {"action":"list_files"}; {"action":"read_file","path":"arquivo"}; {"action":"write_file","path":"arquivo","content":"conteúdo integral do arquivo","reason":"motivo"}; ou {"action":"finish","summary":"resumo","checks":["checagem feita ou recomendada"]}. Para arquivos existentes, leia antes de sobrescrever quando necessário. Prefira mudanças pequenas e coerentes, mobile-first, acessíveis e sem dependências desnecessárias. Nunca alegue que executou testes ou comandos: não há terminal disponível nesta sessão do agente. Não escreva segredos nem arquivos .env. Não altere package.json para incluir scripts que executem comandos perigosos. Pode criar/editar arquivos HTML, CSS, JS, TS, TSX, JSON e Markdown. Não invente APIs. Termine quando a solução estiver implementada ou explicar honestamente o que falta.`;
 const messages:Array<{role:string;content:string}>=[{role:'system',content:system},{role:'user',content:prompt}];
 try {
  for(let i=0;i<(parsed.data.maxSteps||8);i++) {
   const response=await fetch(`${process.env.AI_BASE_URL!.replace(/\/$/,'')}/chat/completions`,{method:'POST',headers:{'Authorization':`Bearer ${process.env.AI_API_KEY}`,'Content-Type':'application/json'},body:JSON.stringify({model:process.env.AI_MODEL,temperature:0.15,max_tokens:5000,messages}),signal:AbortSignal.timeout(60000)});
   if(!response.ok){const body=(await response.text()).slice(0,300);return res.status(response.status===429?429:502).json({error:`Falha do provedor (HTTP ${response.status}).`,detail:body,files,steps});}
   const data=await response.json() as {choices?:{message?:{content?:string}}[]};
   const content=(data.choices?.[0]?.message?.content||'').replace(/^```(?:json)?\s*/i,'').replace(/\s*```$/,'').trim();
   let raw:unknown; try{raw=JSON.parse(content)}catch{messages.push({role:'assistant',content});messages.push({role:'user',content:'Sua resposta não era JSON válido. Responda agora com um único objeto JSON válido conforme os formatos definidos.'});steps.push(`Etapa ${i+1}: resposta inválida; solicitada correção.`);continue;}
   const action=agentActionSchema.safeParse(raw); if(!action.success){messages.push({role:'assistant',content});messages.push({role:'user',content:'A ação não passou na validação. Use exatamente um dos formatos permitidos e caminhos relativos seguros.'});steps.push(`Etapa ${i+1}: ação rejeitada pela validação.`);continue;}
   const a=action.data;
   if(a.action==='finish'){summary=a.summary;checks=a.checks;steps.push(`Finalização: ${a.summary}`);break;}
   if(a.action==='list_files') {const names=Object.keys(files);messages.push({role:'assistant',content});messages.push({role:'user',content:`Resultado da ferramenta list_files: ${JSON.stringify(names)}. Escolha a próxima ação.`});steps.push(`Etapa ${i+1}: listou ${names.length} arquivo(s).`);continue;}
   if(!safePath(a.path)){messages.push({role:'assistant',content});messages.push({role:'user',content:'Caminho rejeitado por segurança. Use apenas caminho relativo simples, sem .., barras invertidas, segredos ou arquivos .env.'});steps.push(`Etapa ${i+1}: caminho rejeitado.`);continue;}
   if(a.action==='read_file'){const found=files[a.path];messages.push({role:'assistant',content});messages.push({role:'user',content:found===undefined?`Resultado read_file: arquivo ${a.path} não existe.`:`Resultado read_file (${a.path}):\n${found}\n\nEscolha a próxima ação.`});steps.push(`Etapa ${i+1}: ${found===undefined?'arquivo ausente':'leu '+a.path}.`);continue;}
   const before=files[a.path]; if(before===undefined&&Object.keys(files).length>=40){messages.push({role:'assistant',content});messages.push({role:'user',content:'Limite de 40 arquivos atingido. Edite arquivos existentes ou finalize.'});continue;}
   const updatedTotal=Object.entries(files).reduce((n,[k,v])=>n+k.length+v.length,0)-(before===undefined?0:a.path.length+before.length)+a.path.length+a.content.length;
   if(updatedTotal>300000){messages.push({role:'assistant',content});messages.push({role:'user',content:'Limite total de 300 KB atingido. Reduza o tamanho do arquivo.'});continue;}
   files[a.path]=a.content; steps.push(`Etapa ${i+1}: ${before===undefined?'criou':'atualizou'} ${a.path}${a.reason?` — ${a.reason}`:''}.`);
   messages.push({role:'assistant',content});messages.push({role:'user',content:`Ferramenta write_file concluída: ${a.path} foi ${before===undefined?'criado':'atualizado'} com sucesso. Próxima ação?`});
  }
  return res.json({ok:true,summary,checks,steps,files,provider:process.env.AI_MODEL,finished:steps.some(s=>s.startsWith('Finalização:'))});
 } catch(error){const message=error instanceof Error?error.message:'Erro desconhecido';return res.status(502).json({error:`Falha no agente: ${message}`,files,steps});}
});

app.use((_req,res)=>res.status(404).json({error:'Endpoint não encontrado.'}));
app.listen(port,()=>console.log(`ASTRA API listening on http://localhost:${port}`));
