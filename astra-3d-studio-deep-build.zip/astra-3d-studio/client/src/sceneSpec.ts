export type SceneSpec = { title: string; subtitle: string; accent: string; object: 'car'|'orb'|'shoe'; motion: number; glow: number };
export const defaultSpec: SceneSpec = { title: 'DESIGNED TO DEFY', subtitle: 'Precisão encontra movimento.', accent: '#6d7cff', object: 'car', motion: 0.7, glow: 0.8 };
export function specFromPrompt(prompt: string, current: SceneSpec = defaultSpec): SceneSpec {
  const p = prompt.toLowerCase();
  const next = { ...current };
  if (/esfera|orb|planeta/.test(p)) next.object = 'orb';
  if (/tênis|tenis|shoe|sneaker/.test(p)) next.object = 'shoe';
  if (/carro|automóvel|automovel|veículo|veiculo|mazda/.test(p)) next.object = 'car';
  if (/roxo|violeta|purple/.test(p)) next.accent = '#a66bff';
  if (/ciano|cyan|turquesa/.test(p)) next.accent = '#36e4ff';
  if (/vermelho|red/.test(p)) next.accent = '#ff4c70';
  if (/verde|green/.test(p)) next.accent = '#56e39a';
  if (/mais lento|suave|slow/.test(p)) next.motion = 0.35;
  if (/rápido|rapido|intenso|fast/.test(p)) next.motion = 1.2;
  const quoted = prompt.match(/[“"]([^”"]{3,60})[”"]/);
  if (quoted) next.title = quoted[1].toUpperCase();
  else if (/título|titulo|headline/.test(p)) next.title = prompt.slice(0, 38).toUpperCase();
  if (/brilho|glow|luminoso/.test(p)) next.glow = Math.min(1.5, next.glow + 0.25);
  return next;
}
