import { describe, expect, it } from 'vitest';
import { defaultSpec, specFromPrompt } from './sceneSpec';
describe('specFromPrompt', () => {
  it('changes the object to an orb', () => expect(specFromPrompt('troque por uma esfera').object).toBe('orb'));
  it('changes accent and motion', () => { const s=specFromPrompt('luzes ciano e movimento mais lento'); expect(s.accent).toBe('#36e4ff'); expect(s.motion).toBe(0.35); });
  it('preserves current state for unsupported prompts', () => expect(specFromPrompt('faça um poema')).toEqual(defaultSpec));
});
