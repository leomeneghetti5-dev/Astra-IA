import { Canvas, useFrame } from '@react-three/fiber';
import { ContactShadows, Environment, Float, OrbitControls, Sparkles, Stage } from '@react-three/drei';
import { Suspense, useRef } from 'react';
import * as THREE from 'three';
import type { SceneSpec } from '../sceneSpec';

function Vehicle({ spec }: { spec: SceneSpec }) {
  const group = useRef<THREE.Group>(null);
  useFrame((state, delta) => { if (group.current) group.current.rotation.y += delta * spec.motion * 0.22; });
  if (spec.object === 'orb') return <Float speed={1.3} rotationIntensity={0.3} floatIntensity={0.6}><mesh castShadow><icosahedronGeometry args={[1.25, 5]} /><meshPhysicalMaterial color="#111a35" metalness={0.9} roughness={0.16} clearcoat={1} emissive={spec.accent} emissiveIntensity={spec.glow * 0.18} /></mesh><mesh scale={1.32}><icosahedronGeometry args={[1, 2]} /><meshBasicMaterial color={spec.accent} wireframe transparent opacity={0.25} /></mesh></Float>;
  if (spec.object === 'shoe') return <group ref={group} rotation={[0.1, -0.25, 0]}><mesh castShadow position={[0, 0, 0]}><capsuleGeometry args={[0.48, 1.35, 8, 20]} /><meshPhysicalMaterial color="#141b2d" metalness={0.3} roughness={0.3} clearcoat={0.9} /></mesh><mesh castShadow position={[0, -0.48, 0.12]} scale={[1.1, 0.16, 0.5]}><sphereGeometry args={[1, 32, 16]} /><meshStandardMaterial color={spec.accent} metalness={0.6} roughness={0.25} /></mesh></group>;
  return <group ref={group} rotation={[0.02, -0.25, 0]}>
    <mesh castShadow receiveShadow position={[0, 0.12, 0]}><boxGeometry args={[3.25, 0.42, 1.45, 8, 2, 4]} /><meshPhysicalMaterial color="#101522" metalness={0.94} roughness={0.19} clearcoat={1} clearcoatRoughness={0.08} /></mesh>
    <mesh castShadow position={[-0.2, 0.48, 0]}><boxGeometry args={[1.55, 0.46, 1.12, 5, 2, 4]} /><meshPhysicalMaterial color="#202c45" metalness={0.8} roughness={0.15} clearcoat={1} /></mesh>
    <mesh position={[-0.2, 0.5, 0]}><boxGeometry args={[1.24, 0.29, 1.15]} /><meshPhysicalMaterial color="#07101e" metalness={0.6} roughness={0.08} transmission={0.12} /></mesh>
    {[-1.02, 1.02].map(x => [-0.72, 0.72].map(z => <group key={`${x}-${z}`} position={[x, -0.18, z]}><mesh rotation={[Math.PI/2,0,0]} castShadow><cylinderGeometry args={[0.34,0.34,0.18,32]} /><meshStandardMaterial color="#080a0f" roughness={0.78} /></mesh><mesh rotation={[Math.PI/2,0,0]}><cylinderGeometry args={[0.21,0.21,0.19,32]} /><meshStandardMaterial color="#8994a9" metalness={0.95} roughness={0.2} /></mesh><mesh rotation={[Math.PI/2,0,0]}><torusGeometry args={[0.25,0.025,8,32]} /><meshStandardMaterial color={spec.accent} emissive={spec.accent} emissiveIntensity={spec.glow * 0.6} /></mesh></group>))}
    <mesh position={[1.65,0.13,0.42]}><boxGeometry args={[0.05,0.09,0.28]} /><meshBasicMaterial color="#ff344f" /></mesh><mesh position={[1.65,0.13,-0.42]}><boxGeometry args={[0.05,0.09,0.28]} /><meshBasicMaterial color="#ff344f" /></mesh>
    <mesh position={[-1.66,0.13,0.42]}><boxGeometry args={[0.04,0.07,0.28]} /><meshBasicMaterial color="#fff4c7" /></mesh><mesh position={[-1.66,0.13,-0.42]}><boxGeometry args={[0.04,0.07,0.28]} /><meshBasicMaterial color="#fff4c7" /></mesh>
  </group>;
}
export default function SceneView({ spec, reducedMotion = false }: { spec: SceneSpec; reducedMotion?: boolean }) {
  return <Canvas shadows dpr={[1, 1.5]} camera={{ position: [4.6, 2.8, 5.8], fov: 40 }} gl={{ antialias: true, powerPreference: 'high-performance' }}>
    <color attach="background" args={['#080b13']} /><fog attach="fog" args={['#080b13', 8, 19]} />
    <ambientLight intensity={0.55} /><spotLight position={[3,7,4]} intensity={110} angle={0.5} penumbra={0.8} castShadow /><pointLight position={[-4,1,-2]} color={spec.accent} intensity={spec.glow * 18} />
    <Suspense fallback={null}><Stage environment="city" intensity={0.45} adjustCamera={false} shadows={false}><Vehicle spec={spec} /></Stage><Environment preset="night" /><ContactShadows position={[0,-0.58,0]} opacity={0.48} scale={10} blur={2.4} far={4} /></Suspense>
    {!reducedMotion && <Sparkles count={38} scale={7} size={1.5} speed={0.2} color={spec.accent} />}
    <gridHelper args={[18,36,'#202943','#101729']} position={[0,-0.62,0]} /><OrbitControls makeDefault enableDamping dampingFactor={0.06} minDistance={3.5} maxDistance={10} maxPolarAngle={Math.PI/2} />
  </Canvas>;
}
